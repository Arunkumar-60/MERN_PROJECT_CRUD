# MERN_PROJECT_CRUD_DEALSDRAY
this is a crud mern project for DEALSDRAY assignment

# API testing done on postman
## link to collection
https://www.postman.com/mission-meteorologist-5176001/workspace/public/collection/24752856-b29e1c51-a8be-4f7b-b060-437fd8489de0?action=share&creator=24752856

